public static class TokenizerMapper
  extends Mapper<Object, Text, Text, IntWritable> {

    private static final int FLUSH_SIZE = 1000;
    private Map<String, Integer> map;

    public void map(Object key, Text value, Context context)
      throws IOException, InterruptedException {
        Map<String, Integer> map = getMap();
        StringTokenizer itr = new StringTokenizer(value.toString());

        while (itr.hasMoreTokens()) {
            String token = itr.nextToken();
            if(map.containsKey(token)) {
                int total = map.get(token).get() + 1;
                map.put(token, total);
            } else {
                map.put(token, 1);
            } //end of if-else
        } //end of while

        flush(context, false);
    } //end of map method

    private void flush(Context context, boolean force) //force==true: flush anyway
      throws IOException, InterruptedException {
        Map<String, Integer> map = getMap();
        if(!force) {
            int size = map.size();
            if(size < FLUSH_SIZE)
                return;
        } //end of if

        Iterator<Map.Entry<String, Integer>> it = map.entrySet().iterator();
        while(it.hasNext()) {
            Map.Entry<String, Integer> entry = it.next();
            String sKey = entry.getKey();
            int total = entry.getValue().intValue();
            context.write(new Text(sKey), new IntWritable(total));
        } //end of while

        map.clear(); //make sure to empty map
    } //end of flush

    protected void cleanup(Context context)
      throws IOException, InterruptedException {
        flush(context, true); //force flush no matter what at the end
    } //end of cleanup


    public Map<String, Integer> getMap() {
      if(null == map)
          map = new HashMap<String, Integer>();
      return map;
    } //end of getMap

} //end of mapper class